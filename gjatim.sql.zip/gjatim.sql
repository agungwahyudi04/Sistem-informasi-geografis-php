--
-- Database: `gjatim`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `gunungjatim`
--

CREATE TABLE `gunungjatim` (
  `idgng` int(11) NOT NULL,
  `Namagng` text NOT NULL,
  `infogng` text NOT NULL,
  `tggigng` text NOT NULL,
  `Alamat` varchar(255) NOT NULL,
  `Lat` varchar(255) NOT NULL,
  `Lng` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gunungjatim`
--

INSERT INTO `gunungjatim` (`idgng`, `Namagng`, `infogng`, `tggigng`, `Alamat`, `Lat`, `Lng`) VALUES
(1, 'GUNUNG SEMERU', 'Gunung Semeru atau Gunung Meru adalah sebuah gunung berapi kerucut di Jawa Timur, Indonesia. Gunung Semeru merupakan gunung tertinggi di Pulau Jawa, dengan puncaknya Mahameru, 3.676 meter dari permukaan laut (mdpl). Gunung Semeru juga merupakan gunung berapi tertinggi ketiga di Indonesia setelah Gunung Kerinci di Sumatra dan Gunung Rinjani di Nusa Tenggara Barat. Kawah di puncak Gunung Semeru dikenal dengan nama Jonggring Saloko. Gunung Semeru secara administratif termasuk dalam wilayah dua kabupaten, yakni Kabupaten Malang dan Kabupaten Lumajang, Provinsi Jawa Timur. Gunung ini termasuk dalam kawasan Taman Nasional Bromo Tengger Semeru. Semeru mempunyai kawasan hutan Dipterokarp Bukit, hutan Dipterokarp Atas, hutan Montane, dan Hutan Ericaceous atau hutan gunung. Pada tahun 1913 dan 1946 Kawah Jonggring Saloka memiliki kubah dengan ketinggian 3.744,8 m hingga akhir November 1973. Di sebelah selatan, kubah ini mendobrak tepi kawah menyebabkan aliran lava mengarah ke sisi selatan meliputi daerah Pronojiwo dan Candipuro di Lumajang. ', 'Gunung Semeru (3.676 MDPL)', 'Ngampo Pasrujambe Kabupaten Lumajang Jawa Timur ', '-8.107611', '112.922343'),
(3, 'GUNUNG ARJUNO', 'Gunung Arjuno (terkadang dieja Gunung Arjuna) adalah sebuah gunung berapi kerucut (istirahat) di Jawa Timur, Indonesia dengan ketinggian 3.339 mdpl. Gunung Arjuno secara administratif terletak di perbatasan Kota Batu, Kabupaten Malang, dan Kabupaten Pasuruan dan berada di bawah pengelolaan Taman Hutan Raya Raden Soerjo. Gunung Arjuno merupakan gunung tertinggi kedua di Jawa Timur setelah Gunung Semeru, serta menjadi yang tertinggi keempat di Pulau Jawa. Biasanya gunung ini dicapai dari tiga titik pendakian yang cukup dikenal yaitu dari Lawang, Tretes dan Batu. Nama Arjuno berasal dari salah satu tokoh pewayangan Mahabharata, Arjuna. Gunung Arjuno bersebelahan dengan Gunung Welirang, Gunung Kembar I, dan Gunung Kembar II. Puncak Gunung Arjuno terletak pada satu punggungan yang sama dengan puncak gunung Welirang, sehingga kompleks ini sering disebut juga dengan Arjuno-Welirang. Kompleks Arjuno-Welirang sendiri berada di dua gunung berapi yang lebih tua, Gunung Ringgit di timur dan Gunung Lincing di selatan. Area fumarol dengan cadangan belerang ditemukan di sejumlah lokasi pegunungan ini, seperti pada puncak Gunung Welirang, puncak Gunung Kembar II, dan pada sejumlah jalur pendakian. ', 'Gunung Arjuno (3.339 MDPL)', ' Pecalukan Barat, Pecalukan Kec. Prigen Pasuruan Jawa Timur ', '-7.724447', '112.589358'),
(4, 'GUNUNG RAUNG', 'Gunung Raung (puncak tertinggi: 3.260 mdpl adalah gunung berapi kerucut yang terletak di ujung timur Pulau Jawa, Indonesia. Secara administratif, kawasan gunung ini termasuk dalam wilayah tiga kabupaten di wilayah Besuki, Jawa Timur, yaitu Banyuwangi, Bondowoso, dan Jember. Secara geografis, lokasi gunung ini berada dalam kawasan kompleks Pegunungan Ijen dan menjadi puncak tertinggi dari gugusan pegunungan tersebut. Dihitung dari titik tertinggi, Gunung Raung merupakan gunung tertinggi ketiga di Jawa Timur setelah Gunung Semeru dan Gunung Arjuno, serta menjadi yang tertinggi keempat di Pulau Jawa. Kaldera Gunung Raung juga merupakan kaldera kering yang terbesar di Pulau Jawa dan terbesar kedua di Indonesia setelah Gunung Tambora di Nusa Tenggara Barat[2]. Terdapat empat titik puncak, yaitu Puncak Bendera, Puncak 17, Puncak Tusuk Gigi, dan, yang tertinggi, Puncak Sejati (3.344 m)', 'Gunung Raung (3.260 MDPL)', ' Area Hutan, Gunosari Tlogosari Kabupaten Bondowoso Jawa Timur ', '-8.1256385', '114.043437'),
(5, 'GUNUNG LAWU', 'Gunung Lawu (3.265 MDPL) terletak di Pulau Jawa, Indonesia, tepatnya di perbatasan Provinsi Jawa Tengah dan Jawa Timur. Gunung Lawu terletak di antara tiga kabupaten yaitu Kabupaten Karanganyar, Jawa Tengah, Kabupaten Ngawi, dan Kabupaten Magetan, Jawa Timur. Status gunung ini adalah gunung api "istirahat" (diperkirakan terahkir meletus pada tanggal 28 November 1885[3][4]) dan telah lama tidak aktif, terlihat dari rapatnya vegetasi serta puncaknya yang tererosi. Di lerengnya terdapat kepundan kecil yang masih mengeluarkan uap air (fumarol) dan belerang (solfatara). Gunung Lawu mempunyai kawasan hutan Dipterokarp Bukit, hutan Dipterokarp Atas, hutan Montane, dan hutan Ericaceous. Gunung Lawu adalah sumber inspirasi dari nama kereta api Argo Lawu, kereta api eksekutif yang melayani Solo Balapan-Gambir. Gunung Lawu memiliki tiga puncak, Puncak Hargo Dalem, Hargo Dumiling dan Hargo Dumilah. Yang terakhir ini adalah puncak tertinggi. Di lereng gunung ini terdapat sejumlah tempat yang populer sebagai tujuan wisata, terutama di daerah Tawangmangu, Cemorosewu, dan Sarangan. Agak ke bawah, di sisi barat terdapat dua komplek percandian dari masa akhir Majapahit: Candi Sukuh dan Candi Cetho. Di kaki gunung ini juga terletak komplek pemakaman kerabat Praja Mangkunagaran: Astana Girilayu dan Astana Mangadeg. Di dekat komplek ini terletak Astana Giribangun, mausoleum untuk keluarga presiden kedua Indonesia, Soeharto. ', 'Gunung Lawu (3.265 MDPL)', ' Area Hutan, Gondosuli Kec. Tawangmangu Kabupaten Karanganyar ', '-7.6274998', '111.1854118'),
(6, 'GUNUNG WELIRANG', 'Gunung Welirang adalah sebuah gunung berapi aktif dengan ketinggian 3.156 m dpl yang secara administratif terletak di perbatasan Kota Batu, Kabupaten Pasuruan, dan Kabupaten Mojokerto, Jawa Timur, Indonesia. Gunung Welirang berada dalam pengelolaan Taman Hutan Raya Raden Soerjo. Gunung Welirang bersebelahan dengan Gunung Arjuno, Gunung Kembar I, dan Gunung Kembar II. Puncak Gunung Welirang terletak pada satu punggungan yang sama dengan puncak gunung Arjuno, sehingga kompleks ini sering disebut juga dengan Arjuno-Welirang. Kompleks Arjuno-Welirang sendiri berada di dua gunung berapi yang lebih tua, Gunung Ringgit di timur dan Gunung Lincing di selatan. Area fumarol dengan cadangan belerang ditemukan di sejumlah lokasi pegunungan ini. "Welirang" atau Walirang (nama kunanya) dalam bahasa Jawa berarti belerang. Di sekujur lerengnya ditumbuhi tetumbuhan kawasan hutan Dipterokarp Bukit, hutan Dipterokarp Atas, hutan Montane, dan Hutan Ericaceous atau hutan gunung. \r\nJalur pendakian dapat dilakukan melalui Desa Jubel, Kecamatan Pacet, Mojokerto. Di bagian sekitar puncak hidup tumbuhan endemik yang dinamakan penduduk setempat sebagai manis rejo. \r\n', 'Gunung Welirang (3.156 MDPL)', ' Area Hutan, Ngadirenggo/Htn Kec. Wlingi Blitar Jawa Timur ', '-7.9166668', '112.4412452'),
(7, 'GUNUNG ARGAPURA', 'Gunung Argapura (sering dieja Gunung Argopuro) adalah sebuah gunung berapi kompleks yang terdapat di Jawa Timur, Indonesia. Gunung Argapura mempunyai ketinggian setinggi 3.088 meter. Gunung Argapura merupakan bekas gunung berapi yang kini sudah tidak aktif lagi. Gunung ini berada kawasan Suaka Margasatwa Pegunungan Yang, sehingga kompleks ini sering disebut Yang-Argapura. Kompleks Yang-Argapura merupakan kompleks gunung berapi raksasa yang mendominasi bentang alam antara Gunung Raung dan Gunung Lemongan di Jawa Timur, Indonesia. Di kompleks ini terdapat untaian lembah sedalam 1.000 m. Pendakian Gunung Argapura memang terbilang memberikan tantangan tersendiri, pasalnya meskipun hanya memiliki ketinggian sekitar 3.088 mdpl, namun jalur pendakiannya cukup panjang. Tak heran jika disebut trek pendakian terpanjang di Pulau Jawa yaitu sekitar 63 Km. Gunung Argapura merupakan puncak tertinggi dari Pegunungan Iyang serta berada pada posisi di antara Gunung Semeru dan Gunung Raung. Ada beberapa puncak yang dimiliki oleh gunung ini. Puncak yang terkenal bernama Puncak Rengganis / Welirang (topografichen Dienst 1928). Sedangkan puncak tertingginya berada pada jarak ± 200 m di arah selatan puncak Rengganis. Puncak tertinggi ini bernama Argopuro dan ditandai dengan sebuah tugu ketinggian (triangulasi). Gunung ini berada dalam wilayah Kabupaten Probolinggo, Kabupaten Lumajang, Kabupaten Jember, Kabupaten Bondowoso, dan Kabupaten Situbondo, dengan puncak Rengganis ada di wilayah Kabupaten Jember. Di kawasan Puncak Rengganis konon menurut cerita masyarakat sekitar bermukim Dewi Rengganis, adik dari Nyi Roro Kidul. ', 'Gunung Argapura (3.088 MDPL)', ' Kalianan Krucil Probolinggo Jawa Timur ', '-7.9637148', '113.5627115'),
(8, 'GUNUNG ANJASMORO', 'Gunung Anjasmoro merupakan sebuah gunung yang terdapat di pulau Jawa, Indonesia. Ketinggian gunung ini ialah 2.282 meter. Gunung Anjasmoro termasuk ke dalam wilayah Kabupaten Jombang, Kabupaten Mojokerto, dan Kota Batu, Jawa Timur. Gunung Anjasmoro terletak satu kluster dengan Gunung Argowayang dan terletak berdekatan dengan Gunung Arjuno-Welirang. Gunung Anjasmoro mempunyai kawasan hutan Dipterokarp Bukit, hutan Dipterokarp Atas, hutan Montane, dan Hutan Ericaceous atau hutan gunung. ', 'Gunung Anjasmoro (2.282 MDPL)', ' Hutan Gondang Mojokerto Jawa Timur ', '-7.7536109', '112.499023'),
(9, 'GUNUNG BROMO', 'Gunung Bromo (dari bahasa Sanskerta: Brahma, salah seorang Dewa Utama dalam agama Hindu) atau dalam bahasa Tengger dieja "Brama", adalah sebuah gunung berapi aktif di Jawa Timur, Indonesia. Gunung ini memiliki ketinggian 2.329 meter di atas permukaan laut dan berada dalam empat wilayah kabupaten, yakni Kabupaten Probolinggo, Kabupaten Pasuruan, Kabupaten Lumajang, dan Kabupaten Malang. Gunung Bromo terkenal sebagai objek wisata utama di Jawa Timur. Sebagai sebuah objek wisata, Bromo menjadi menarik karena statusnya sebagai gunung berapi yang masih aktif. Gunung Bromo termasuk dalam kawasan Taman Nasional Bromo Tengger Semeru. Bentuk tubuh Gunung Bromo bertautan antara lembah dan ngarai dengan kaldera atau lautan pasir seluas sekitar 10 kilometer persegi. Ia mempunyai sebuah kawah dengan garis tengah ± 800 meter (utara-selatan) dan ± 600 meter (timur-barat). Sedangkan daerah bahayanya berupa lingkaran dengan jari-jari 4 km dari pusat kawah Bromo. ', 'Gunung Bromo (2.329 MDPL)', ' Area Gn. Bromo, Podokoyo Tosari Pasuruan Jawa Timur ', '-7.9424934', '112.9442574'),
(10, 'GUNUNG WILIS', 'Gunung Wilis adalah sebuah gunung berapi (istirahat) yang terletak di Jawa Timur, Indonesia. Gunung Wilis memiliki ketinggian 2.563 meter di atas permukaan laut (mdpl) dan termasuk dalam wilayah enam kabupaten yaitu Kabupaten Kediri, Kabupaten Tulungagung, Kabupaten Nganjuk, Kabupaten Madiun, Kabupaten Ponorogo, dan Kabupaten Trenggalek. Gunung Wilis mempunyai kawasan hutan Dipterokarp Bukit, hutan Dipterokarp Atas, hutan Montane, dan hutan Ericaceous atau hutan gunung. Daerah perbukitan Gunung Wilis pernah dilalui oleh Jenderal Sudirman, sebelum melakukan Serangan Umum 1 Maret 1949 ke Yogyakarta. ', 'Gunung Wilis (2.563 MDPL)', ' Tawang, Banaran Pulung Kabupaten Ponorogo Jawa Timur ', '-7.8204385', '111.7367324,14'),
(11, 'GUNUNG LIMAN', 'Gunung Liman (terkadang dieja Gunung Ngliman) adalah sebuah gunung berapi (istirahat) yang terletak di Jawa Timur, Indonesia. Gunung Liman secara administratif termasuk dalam wilayah dua kabupaten yaitu Kabupaten Ponorogo dan Kabupaten Nganjuk. Gunung Liman terletak satu kluster dengan Gunung Wilis dan merupakan salah satu dari beberapa gunung yang terletak di pegunungan Wilis. gunung ini memiliki ketinggian 2.563 m (8.410 kaki)', 'Gunung Liman (2.563 MDPL)', ' Tawang, Banaran Pulung Kabupaten Ponorogo Jawa Timur ', '-7.8139514', '111.7512454'),
(12, 'GUNUNG BUTAK', 'Gunung Butak adalah gunung stratovolcano yang terletak di Kabupaten Malang, Jawa Timur, Indonesia. Gunung Butak terletak berdekatan dengan Gunung Kawi. Tidak diketemukan catatan sejarah atas erupsi dari Gunung Butak sampai saat ini.[1] Gunung ini berada pada posisi -7,922566? dan 112,451688? dengan ketinggial 2.868 mdpl(9,409 ft). Gunung Butak keseluruhan memiliki konfigurasi lahan bervariasi antara lain sedikit datar dan luas,kebanyakkan jalur pendakiannya terjal dan melewati kebun teh .', 'Gunung Butak (2.868 MDPL)', ' Area Hutan, Ngadirenggo/Htn Kec. Wlingi Blitar Jawa Timur ', '-7.9199958', '112.4412114'),
(13, 'GUNUNG IJEN', 'Gunung Ijen adalah sebuah gunung berapi yang terletak di perbatasan antara Kabupaten Banyuwangi dan Kabupaten Bondowoso, Jawa Timur, Indonesia. Gunung ini memiliki ketinggian 2.386 mdpl dan terletak berdampingan dengan Gunung Marapi. Gunung Ijen terakhir meletus pada tahun 1999. Salah satu fenomena alam yang paling terkenal dari Gunung Ijen adalah blue fire di dalam kawah yang terletak di puncaknya. Pendakian gunung ini bisa dimulai dari dua tempat. Pendaki bisa berangkat dari Banyuwangi ataupun dari Bondowoso.', 'Gunung Ijen (2.386 MDPL)', ' Gn. Ijen Jawa Timur ', '-8.0588232', '114.2352034'),
(14, 'GUNUNG ARGOWAYANG', 'Gunung Argowayang adalah sebuah gunung yang terletak di Provinsi Jawa Timur. Gunung ini termasuk ke dalam wilayah dua kabupaten yaitu Kabupaten Jombang dan Kabupaten Malang. Letak gunung Argowayang satu kluster dengan Gunung Anjasmoro dan berdekatan dengan Gunung Arjuno-Welirang. Gunung ini memiliki ketinggian adalah 2.198 Mdpl.', 'Gunung Argowayang (2.198 MDPL)', ' Wiyurejo Kec. Pujon Malang Jawa Timur ', '-7.7727776', '112.421523'),
(15, 'GUNUNG KAWI', 'Gunung Kawi adalah sebuah gunung berapi di Kabupaten Malang, Jawa Timur, Indonesia, dekat dengan Gunung Butak. Tidak ada catatan sejarah mengenai letusan gunung berapi ini. Gunung ini cukup dikenal karena adanya tempat ziarah Pesarean Gunung Kawi.Ketinggian gunung Kiwi adalah 2.551 mdpl', 'Gunung Kawi (2.551 MDPL)', 'Area Hutan, Ngadirenggo/Htn\r\nKec. Wlingi\r\nBlitar\r\nJawa Timur ', '-7.9549998', '112.4562452');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftarangunung`
--

CREATE TABLE `pendaftarangunung` (
  `iddaftargng` int(11) NOT NULL,
  `daftarnamagng` varchar(100) NOT NULL,
  `linkdaftargng` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendaftarangunung`
--

INSERT INTO `pendaftarangunung` (`iddaftargng`, `daftarnamagng`, `linkdaftargng`) VALUES
(2, 'SEMERU', 'https://bookingsemeru.bromotenggersemeru.org/'),
(3, 'WELIRANG', 'https://sipenerang.tahuraradensoerjo.or.id/registrasi/sop'),
(4, 'ARJUNO', 'https://sipenerang.tahuraradensoerjo.or.id/registrasi/sop'),
(5, 'PUNDAK', 'https://sipenerang.tahuraradensoerjo.or.id/registrasi/sop ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gunungjatim`
--
ALTER TABLE `gunungjatim`
  ADD PRIMARY KEY (`idgng`);

--
-- Indexes for table `pendaftarangunung`
--
ALTER TABLE `pendaftarangunung`
  ADD PRIMARY KEY (`iddaftargng`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gunungjatim`
--
ALTER TABLE `gunungjatim`
  MODIFY `idgng` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `pendaftarangunung`
--
ALTER TABLE `pendaftarangunung`
  MODIFY `iddaftargng` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
